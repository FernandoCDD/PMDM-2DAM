import { Component } from '@angular/core';

@Component({
  selector: 'app-page-home-component',
  templateUrl: './page-home-component.component.html',
  styleUrls: ['./page-home-component.component.css']
})
export class PageHomeComponent {

}
